﻿
//$(document).ready(function () {
//    //function CategoryDetail() {

//    //}
//    $("#ShowAddCategoryPopup").click(function () {
//        $("#CategoryId").val(0);
//        $("#CategoryModal").show()
//    })
//    $("#SaveCategory").click(function () {
//        debugger;
//        //var isValid = $("#FormCategory").isValid();
//        //if (isValid) {
//        $("#CategoryId").val(0);
//            var formData = $("#FormCategory").serialize();
//            $.ajax({
//                url: '/Category/SaveCategory',
//                type: 'POST',
//                data: formData,
//                success: function (response) {
//                    //location.reload()
//                }
//            })
//        //}
//    });
//    $("#CloseCategory").click(function () {
//        $("#CategoryModal").hide()
//    });
//})

$(document).ready(function () {
    CategoryServerSide();
});

function CategoryServerSide() {
    $('#category-bulk-table').DataTable({
        dom: 'Bfrtip',
        lengthMenu: [
            [10, 25, 50, -1],
            ['10 rows', '25 rows', '50 rows', 'Show all']
        ],
        buttons: [
            'pageLength',
            'colvis'
        ],
        "processing": true,
        "bServerSide": true,
        "order": [0, 'desc'],
        "searchDelay": 600,
        "sAjaxSource": "/Category/CategoryBulkServerSideIndex",
        "fnServerData": function (sSource, aoData, fnCallback) {
            $.ajax({
                type: "POST",
                data: aoData,
                url: sSource,
                dataType: 'json',
                success: function (response) {
                    console.log(response); // Log the response to verify structure
                    fnCallback(response);
                }
            });
        },
        bDestroy: true,
        "columns": [
            { "data": "categoryId", title: 'Category Id' },
            { "data": "categoryName", title: 'Category Name' },
            {
                title: 'Action',
                data: "categoryId", // Use categoryId for creating actions
                render: function (data, type, row) {
                    return `
                        <a href="#" class="btn btn-sm btn-primary" onclick="viewCategory(${data})" title="View">
                            <i class="fa fa-eye"></i> View
                        </a>
                        <a href="#" class="btn btn-sm btn-warning" onclick="editCategory(${data})" title="Edit">
                            <i class="fa fa-pencil"></i> Edit
                        </a>
                        <a href="#" class="btn btn-sm btn-danger" onclick="deleteCategory(${data})" title="Delete">
                            <i class="fa fa-trash"></i> Delete
                        </a>`;
                }
            }
        ]
    });
}

// View Category Function
function viewCategory(categoryId) {
    // Redirect to the Details action with the Category ID
    window.location.href = `/Category/Details/${categoryId}`;
}
// Edit Category Function
function editCategory(categoryId) {
    // Redirect to the Edit action with the Category ID
    window.location.href = `/Category/Edit/${categoryId}`;
}

// Delete Category Function
function deleteCategory(categoryId) {
    if (confirm("Are you sure you want to delete this category?")) {
        // Retrieve the anti-forgery token
        const token = $('input[name="__RequestVerificationToken"]').val();

        $.ajax({
            url: `/Category/Delete/${categoryId}`,
            type: 'POST',
            headers: { 'RequestVerificationToken': token }, // Add token in headers
            success: function (response) {
                if (response.success) {
                    alert(response.message);
                    $('#category-bulk-table').DataTable().ajax.reload();
                } else {
                    alert(response.message);
                }
            },
            error: function () {
                alert("An error occurred while deleting the category.");
            }
        });
    }
}

