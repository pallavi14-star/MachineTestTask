﻿$(document).ready(function () {
    ProductServerSide();
});

function ProductServerSide() {
    $('#product-bulk-table').DataTable({
        dom: 'Bfrtip',
        lengthMenu: [
            [10, 25, 50, -1],
            ['10 rows', '25 rows', '50 rows', 'Show all']
        ],
        buttons: [
            'pageLength',
            'colvis'
        ],
        "processing": true,
        "bServerSide": true,
        "order": [0, 'desc'],
        "searchDelay": 600,
        "sAjaxSource": "/Product/ProductBulkServerSideIndex",
        "fnServerData": function (sSource, aoData, fnCallback) {
            $.ajax({
                type: "POST",
                data: aoData,
                url: sSource,
                dataType: 'json',
                success: function (response) {
                    console.log(response); // Log the response to verify structure
                    fnCallback(response);
                }
            });
        },
        bDestroy: true,
        "columns": [
            { "data": "productId", title: 'Product Id' },
            { "data": "productName", title: 'Product Name' },
            { "data": "categoryId", title: 'Category Id' },
            { "data": "categoryName", title: 'Category Name' },
            {
                title: 'Action',
                data: "productId", // Use ProductId for creating actions
                render: function (data, type, row) {
                    return `
                        <a href="#" class="btn btn-sm btn-primary" onclick="viewProduct(${data})" title="View">
                            <i class="fa fa-eye"></i> View
                        </a>
                        <a href="#" class="btn btn-sm btn-warning" onclick="editProduct(${data})" title="Edit">
                            <i class="fa fa-pencil"></i> Edit
                        </a>
                        <a href="#" class="btn btn-sm btn-danger" onclick="deleteProduct(${data})" title="Delete">
                            <i class="fa fa-trash"></i> Delete
                        </a>`;
                }
            }
        ]
    });
}

// View Product Function
function viewProduct(productId) {
    // Redirect to the Details action with the Product ID
    window.location.href = `/Product/Details/${productId}`;
}
// Edit Product Function
function editProduct(productId) {
    // Redirect to the Edit action with the Product ID
    window.location.href = `/Product/Edit/${productId}`;
}

// Delete Product Function
function deleteProduct(productId) {
    if (confirm("Are you sure you want to delete this product?")) {
        // Retrieve the anti-forgery token
        const token = $('input[name="__RequestVerificationToken"]').val();

        $.ajax({
            url: `/Product/Delete/${productId}`,
            type: 'POST',
            headers: { 'RequestVerificationToken': token }, // Add token in headers
            success: function (response) {
                if (response.success) {
                    alert(response.message);
                    $('#product-bulk-table').DataTable().ajax.reload();
                } else {
                    alert(response.message);
                }
            },
            error: function () {
                alert("An error occurred while deleting the product.");
            }
        });
    }
}

