﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using ProductProject.Models;
using ProductProject.Models.Context;
using ProductProject.Models.ListViewModel;

namespace ProductProject.Controllers
{
    public class CategoryController : Controller
    {
        private readonly ApplicationDbContext _context;
        public CategoryController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: CategoryController
        public ActionResult Index()
        {
            var categoryList = new CategoryListViewModel();
            categoryList.CategoryList = _context.Category.Where(x => x.IsDeleted == false).ToList();
            return View(categoryList);
        }

        // GET: CategoryController/Details/5
        public ActionResult Details(int id)
        {
            var response = new Category();
            response = _context.Category.Where(x => x.CategoryId == id).FirstOrDefault();
            return View(response);
        }

        // GET: CategoryController/Create
        public ActionResult Create()
        {
            var categoryModel = new Category();
            return View(categoryModel);
        }

        // POST: CategoryController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection, Category model)
        {
            try
            {
                if (model != null)
                {
                    model.IsDeleted = false;
                    model.CreatedDate = DateTime.Now;
                }
                _context.Category.Add(model);
                _context.SaveChanges();
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: CategoryController/Edit/5
        public ActionResult Edit(int id)
        {
            var response = _context.Category.Where(x => x.CategoryId == id).FirstOrDefault();
            return View(response);
        }

        // POST: CategoryController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, Category model)
        {
            try
            {
                model.CategoryId = id;
                model.UpdatedDate = DateTime.Now;
                _context.Category.Update(model);
                _context.SaveChanges();
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        [HttpPost]
        [Route("Category/Delete/{categoryId}")]
        public JsonResult Delete(int categoryId)
        {
            try
            {
                var category = _context.Category.FirstOrDefault(x => x.CategoryId == categoryId);
                if (category != null)
                {
                    category.IsDeleted = true;
                    _context.Category.Update(category);
                    _context.SaveChanges();
                    return Json(new { success = true, message = "Category deleted successfully!" });
                }

                return Json(new { success = false, message = "Category not found!" });
            }
            catch (Exception ex)
            {
                // Log the error
                Console.WriteLine(ex.Message);

                return Json(new { success = false, message = "An error occurred while deleting the category." });
            }
        }

        // POST: CategoryController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        #region Pagination

        [HttpPost]
        public IActionResult CategoryBulkServerSideIndex(DatatableParam param)
        {
            SqlParameter[] parameters = new SqlParameter[]
            {
    new SqlParameter("@iDisplayStart", param.iDisplayStart),
    new SqlParameter("@iDisplayLength", param.iDisplayLength),
    new SqlParameter("@iSortCol_0", param.iSortCol_0),
    new SqlParameter("@sSortDir_0", param.sSortDir_0),
    new SqlParameter("@sSearch", param.sSearch ?? ""),

            };
            int TotalDisplayRecords = 0;
            int TotalRecords = 0;
            double TotalAmount = 0.00;

            List<CategorySPResponse> sspSchList = _context.CategorySPResponse.FromSqlRaw("EXEC CategorySPRecords @iDisplayStart, @iDisplayLength, @iSortCol_0, @sSortDir_0, @sSearch", parameters).ToList();

            CategorySPResponse dummy = sspSchList.LastOrDefault();
            if (dummy != null)
            {
                TotalDisplayRecords = dummy.TotalCount;
            }

            TotalRecords = _context.Category.Count();

            return Json(new
            {
                aaData = sspSchList,
                sEcho = param.sEcho,
                iTotalDisplayRecords = TotalDisplayRecords,
                fTotalAmount = TotalAmount,
                iTotalRecords = TotalRecords
            });

        }

        public IQueryable<Category> queryBuilder(IQueryable<Category> query, int sortCol, string sortDir)
        {
            switch (sortCol)
            {
                case 0:
                    query = (sortDir == "asc") ? query.OrderBy(x => x.CategoryId) : query.OrderByDescending(x => x.CategoryId);
                    ;
                    break;
                case 1:
                    query = (sortDir == "asc") ? query.OrderBy(x => x.CategoryName) : query.OrderByDescending(x => x.CategoryName);
                    break;
            }

            return query;
        }
        #endregion
    }
}
