﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Extensions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using ProductProject.Models;
using ProductProject.Models.Context;
using ProductProject.Models.ListViewModel;

namespace ProductProject.Controllers
{
    public class ProductController : Controller
    {
        private readonly ApplicationDbContext _context;
        public ProductController(ApplicationDbContext context)
        {
            _context = context;
        }
        // GET: ProductController
        public ActionResult Index()
        {
            var productList = new ProductListViewModel();
            productList.ProductList = _context.Product.Where(x => x.IsDeleted == false).ToList();
            foreach (var item in productList.ProductList)
            {
                item.CategoryName = _context.Category.Where(x => x.CategoryId == item.CategoryId && x.IsDeleted == false).FirstOrDefault().CategoryName;
            }
            return View(productList);
        }

        // GET: ProductController/Details/5
        public ActionResult Details(int id)
        {
            var response = new Product();
            response = _context.Product.Where(x => x.ProductId == id).FirstOrDefault();
            response.CategoryName = _context.Category.Where(x => x.CategoryId == response.CategoryId).FirstOrDefault().CategoryName;
            return View(response);
        }

        // GET: ProductController/Create
        public ActionResult Create()
        {
            var productModel = new Product
            {
                CategoryList = _context.Category.Where(x => x.IsDeleted == false).ToList()
            };
            return View(productModel);
        }

        // POST: ProductController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection, Product model)
        {
            try
            {
                if (model != null)
                {
                    model.IsDeleted = false;
                    model.CreatedDate = DateTime.Now;
                }
                _context.Product.Add(model);
                _context.SaveChanges();
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: ProductController/Edit/5
        public ActionResult Edit(int id)
        {
            var response = _context.Product.Where(x => x.ProductId == id).FirstOrDefault();
            response.CategoryList = _context.Category.Where(x => x.IsDeleted == false).ToList();
            return View(response);
        }

        // POST: ProductController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, Product model)
        {
            try
            {
                model.ProductId = id;
                model.UpdatedDate = DateTime.Now;
                _context.Product.Update(model);
                _context.SaveChanges();
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        //// GET: ProductController/Delete/5
        //public ActionResult Delete(int id)
        //{
        //    var response = _context.Product.Where(x => x.ProductId == id).FirstOrDefault();
        //    if (response != null)
        //    {
        //        response.IsDeleted = true;
        //        _context.Product.Update(response);
        //        _context.SaveChanges();
        //    }
        //    return RedirectToAction(nameof(Index));
        //}

        [HttpPost]
        [Route("Product/Delete/{productId}")]
        public JsonResult Delete(int productId)
        {
            try
            {
                var product = _context.Product.FirstOrDefault(x => x.ProductId == productId);
                if (product != null)
                {
                    product.IsDeleted = true;
                    _context.Product.Update(product);
                    _context.SaveChanges();
                    return Json(new { success = true, message = "Product deleted successfully!" });
                }

                return Json(new { success = false, message = "Product not found!" });
            }
            catch (Exception ex)
            {
                // Log the error
                Console.WriteLine(ex.Message);

                return Json(new { success = false, message = "An error occurred while deleting the product." });
            }
        }



        #region Pagination

        [HttpPost]
        public IActionResult ProductBulkServerSideIndex(DatatableParam param)
        {
            SqlParameter[] parameters = new SqlParameter[]
            {
    new SqlParameter("@iDisplayStart", param.iDisplayStart),
    new SqlParameter("@iDisplayLength", param.iDisplayLength),
    new SqlParameter("@iSortCol_0", param.iSortCol_0),
    new SqlParameter("@sSortDir_0", param.sSortDir_0),
    new SqlParameter("@sSearch", param.sSearch ?? ""),

            };
            int TotalDisplayRecords = 0;
            int TotalRecords = 0;
            double TotalAmount = 0.00;

            List<ProductSPResponse> sspSchList = _context.ProductSPResponse.FromSqlRaw("EXEC ProductSPRecords @iDisplayStart, @iDisplayLength, @iSortCol_0, @sSortDir_0, @sSearch", parameters).ToList();

            ProductSPResponse dummy = sspSchList.LastOrDefault();
            if (dummy != null)
            {
                TotalDisplayRecords = dummy.TotalCount;
            }

            TotalRecords = _context.Product.Count();

            return Json(new
            {
                aaData = sspSchList,
                sEcho = param.sEcho,
                iTotalDisplayRecords = TotalDisplayRecords,
                fTotalAmount = TotalAmount,
                iTotalRecords = TotalRecords
            });

        }

        public IQueryable<Product> queryBuilder(IQueryable<Product> query, int sortCol, string sortDir)
        {
            switch (sortCol)
            {
                case 0:
                    query = (sortDir == "asc") ? query.OrderBy(x => x.ProductId) : query.OrderByDescending(x => x.ProductId);
                    ;
                    break;
                case 1:
                    query = (sortDir == "asc") ? query.OrderBy(x => x.ProductName) : query.OrderByDescending(x => x.ProductName);
                    break;
                case 2:
                    query = (sortDir == "asc") ? query.OrderBy(x => x.CategoryId) : query.OrderByDescending(x => x.CategoryId);
                    break;
                case 3:
                    query = (sortDir == "asc") ? query.OrderBy(x => x.CategoryName) : query.OrderByDescending(x => x.CategoryName);
                    break;
            }

            return query;
        }
        #endregion
    }
}
