﻿namespace ProductProject.Models.ListViewModel
{
    public class ProductListViewModel
    {
        public ProductListViewModel()
        {
            ProductList = new List<Product>();
        }

        public List<Product> ProductList { get; set; }
    }
}
