﻿namespace ProductProject.Models.ListViewModel
{
    public class CategoryListViewModel
    {
        public CategoryListViewModel()
        {
            CategoryList = new List<Category>();
        }

        public List<Category> CategoryList { get; set; }
    }
}
