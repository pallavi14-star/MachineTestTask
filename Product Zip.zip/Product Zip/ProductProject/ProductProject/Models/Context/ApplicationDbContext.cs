﻿using Microsoft.EntityFrameworkCore;
using System.Reflection.Emit;

namespace ProductProject.Models.Context
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }

        public DbSet<Product> Product { get; set; }
        public virtual DbSet<CategorySPResponse> CategorySPResponse { get; set; }
        public virtual DbSet<ProductSPResponse> ProductSPResponse { get; set; }

        public DbSet<Category> Category { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<ProductSPResponse>().HasNoKey();
            modelBuilder.Entity<CategorySPResponse>().HasNoKey();
            base.OnModelCreating(modelBuilder);
        }
    }
}
