﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ProductProject.Models
{
    public class Product : BaseModel
    {
        public Product()
        {
            CategoryList = new List<Category>();
        }
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int ProductId { get; set; }

        [Display(Name = "Product Name")]
        public string ProductName { get; set; }

        [Display(Name = "Category")]
        public int CategoryId { get; set; }

        #region View Model

        [NotMapped]
        public string CategoryName { get; set; }
        [NotMapped]
        public List<Category> CategoryList { get; set; }
        #endregion
    }
}
