﻿namespace ProductProject.Models
{
    public class CategorySPResponse
    {
        public int CategoryId { get; set; }
        public string CategoryName { get; set; }
        public long RowNum { get; set; }
        public int TotalCount { get; set; }
    }
}
