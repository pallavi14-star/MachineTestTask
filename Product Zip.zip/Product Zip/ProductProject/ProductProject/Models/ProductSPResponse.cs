﻿namespace ProductProject.Models
{
    public class ProductSPResponse
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public int CategoryId { get; set; }
        public string CategoryName { get; set; }
        public long RowNum { get; set; }
        public int TotalCount { get; set; }
    }
}
