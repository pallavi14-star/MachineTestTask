﻿namespace ProductProject.Models.ViewModel
{
    public class ProductDataTableResponse
    {
        public int draw { get; set; }
        public int recordsFiltered { get; set; }
        public int recordsTotal { get; set; }
        public List<ProductListResponse> data { get; set; }
    }
}
